# Dummy data
sales_data = {
    "Antena A": 10,
    "Antena B": 20,
    "Antena C": 30,
    "Antena D": 40,
    "Antena E": 50
}

inventory_data = {
    "Antena A": 2,
    "Antena B": 3,
    "Antena C": 5,
    "Antena D": 8,
    "Antena E": 10
}

product_data = {
    "A": 10,
    "B": 40,
    "C": 30,
    "D": 20,
    "E": 50
}

sales_year_data = {
    2018: 5000,
    2019: 17500,
    2020: 10000,
    2021: 7500,
    2022: 15000
}

inventory_month_data = {
    "Jan": 200,
    "Feb": 300,
    "Mar": 800,
    "Apr": 1300,
    "May": 600,
    "Jun": 900,
    "Jul": 700,
    "Aug": 900,
    "Sep": 1000,
    "Oct": 300,
    "Nov": 450,
    "Dec": 1300
}